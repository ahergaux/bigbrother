-- DB BigBrother
-- Creé le 08/11/2024
-- Version 1.0
-- Initialisation DataBase
-- init_setup.sql


\i structures/create_database.sql
\i fonctions/fonction_manip.sql
\i fonctions/fonction.sql
\i structures/tablesdefinition.sql
\i structures/tablesinitiale.sql
\i structures/tablelog.sql
\i data/init_data.sql
\i data/data_file.sql
\i view/view.sql

